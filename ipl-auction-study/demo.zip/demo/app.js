const categorySelect = document.getElementById("categorySelect");
const queryTypeSelect = document.getElementById("queryTypeSelect");
const teamSelect = document.getElementById("teamSelect");
const seasonSelect = document.getElementById("seasonSelect");
const playerSelect = document.getElementById("playerSelect");
const resultBox = document.getElementById("resultBox");

const wraps = {
  query: document.getElementById("queryTypeWrap"),
  team: document.getElementById("teamWrap"),
  season: document.getElementById("seasonWrap"),
  player: document.getElementById("playerWrap"),
};

const state = {
  batting: [],
  bowling: [],
  values: [],
  awards: [],
  seasons: [],
  teams: [],
};

const statSeasons = document.getElementById("statSeasons");
const statPlayers = document.getElementById("statPlayers");
const statDeliveries = document.getElementById("statDeliveries");
const statHitRate = document.getElementById("statHitRate");

const queryMap = {
  "Team Records": [
    "Top batsmen in selected team",
    "Top bowlers in selected team",
    "Best player in selected team for a season",
  ],
  "Player Records - Batting": [
    "Runs by a player in a season",
    "Top 5 batsmen in a season",
    "Highest run scorer in a season",
    "Best strike rate players (min 100 balls)",
  ],
  "Player Records - Bowling": [
    "Bowling stats of a player in a season",
    "Most wickets in a season",
    "Best bowler in a season (wickets)",
    "Best economy bowlers",
  ],
  "Auction Records": [
    "Was highest-paid player worth it for a season?",
    "Best value highest-buy player",
    "Worst value highest-buy player",
    "Top 5 value-for-money highest-buys",
    "Bottom 5 overpriced highest-buys",
    "How often did highest-buy players deliver good value?",
  ],
  "Other": ["Reserved for later"],
};

function parseCSV(text) {
  return Papa.parse(text, { header: true, skipEmptyLines: true, dynamicTyping: true }).data;
}

async function loadCSV(path) {
  const res = await fetch(path);
  if (!res.ok) throw new Error(`Failed to load ${path}`);
  const txt = await res.text();
  return parseCSV(txt);
}

function setOptions(select, options) {
  select.innerHTML = "";
  options.forEach((opt) => {
    const el = document.createElement("option");
    el.value = String(opt);
    el.textContent = String(opt);
    select.appendChild(el);
  });
}

function getValueVerdict(v) {
  if (v >= 30) return "High Value";
  if (v >= 15) return "Average";
  return "Overpriced";
}

function updatePlayers() {
  const season = Number(seasonSelect.value);
  const category = categorySelect.value;
  let list = [];
  if (category === "Player Records - Batting") {
    list = state.batting.filter((r) => Number(r.season) === season).map((r) => r.player);
  } else if (category === "Player Records - Bowling") {
    list = state.bowling.filter((r) => Number(r.season) === season).map((r) => r.player);
  }
  list = [...new Set(list)].sort((a, b) => String(a).localeCompare(String(b)));
  setOptions(playerSelect, list.length ? list : ["N/A"]);
}

function updateUI() {
  const category = categorySelect.value;
  setOptions(queryTypeSelect, queryMap[category] || []);

  wraps.team.classList.toggle("hidden", category !== "Team Records");
  wraps.player.classList.toggle("hidden", !category.startsWith("Player Records"));
  wraps.season.classList.toggle("hidden", category === "Other");
  wraps.query.classList.toggle("hidden", false);

  if (category.startsWith("Player Records")) updatePlayers();
}

function num(v, fallback = 0) {
  return Number.isFinite(Number(v)) ? Number(v) : fallback;
}

function runQuery() {
  const category = categorySelect.value;
  const q = queryTypeSelect.value;
  const team = teamSelect.value;
  const season = Number(seasonSelect.value);
  const player = playerSelect.value;

  if (category === "Other") {
    resultBox.textContent = "Other is reserved for future expansion.";
    return;
  }

  if (category === "Auction Records") {
    const big = state.values.filter((r) => r.is_big_buy === true || r.is_big_buy === "True");
    const merged = big.map((r) => {
      const a = state.awards.find((x) => Number(x.season) === Number(r.season)) || {};
      return { ...r, ...a };
    });

    if (q === "Was highest-paid player worth it for a season?") {
      const row = merged.find((r) => Number(r.season) === season);
      if (!row) return (resultBox.textContent = `No data for season ${season}`);
      resultBox.textContent =
`${row.highest_buy_player} (${season})
- Price: Rs ${num(row.price_cr).toFixed(2)} Cr
- Runs: ${num(row.buy_runs)} | SR: ${num(row.buy_sr).toFixed(2)}
- Wickets: ${num(row.buy_wickets)} | Economy: ${num(row.buy_economy).toFixed(2)}
- Value Score: ${num(row.value_score).toFixed(2)}

Verdict: ${getValueVerdict(num(row.value_score))}
Insight: Combined batting + bowling contribution against auction price.`;
      return;
    }

    const sortedDesc = [...merged].sort((a, b) => num(b.value_score) - num(a.value_score));
    const sortedAsc = [...merged].sort((a, b) => num(a.value_score) - num(b.value_score));
    if (q === "Best value highest-buy player") {
      const r = sortedDesc[0];
      resultBox.textContent = `Best value highest-buy: ${r.player} (${r.season}) with value score ${num(r.value_score).toFixed(2)}.`;
      return;
    }
    if (q === "Worst value highest-buy player") {
      const r = sortedAsc[0];
      resultBox.textContent = `Worst value highest-buy: ${r.player} (${r.season}) with value score ${num(r.value_score).toFixed(2)}.`;
      return;
    }
    if (q === "Top 5 value-for-money highest-buys") {
      resultBox.textContent = sortedDesc.slice(0, 5)
        .map((r, i) => `${i + 1}. ${r.player} (${r.season}) - ${num(r.value_score).toFixed(2)}`)
        .join("\n");
      return;
    }
    if (q === "Bottom 5 overpriced highest-buys") {
      resultBox.textContent = sortedAsc.slice(0, 5)
        .map((r, i) => `${i + 1}. ${r.player} (${r.season}) - ${num(r.value_score).toFixed(2)}`)
        .join("\n");
      return;
    }
    if (q === "How often did highest-buy players deliver good value?") {
      const labels = merged.map((r) => getValueVerdict(num(r.value_score)));
      const high = labels.filter((x) => x === "High Value").length;
      const avg = labels.filter((x) => x === "Average").length;
      const low = labels.filter((x) => x === "Overpriced").length;
      resultBox.textContent =
`Distribution across ${labels.length} seasons:
- High Value: ${high}
- Average: ${avg}
- Overpriced: ${low}`;
      return;
    }
  }

  if (category === "Player Records - Batting") {
    const rows = state.batting.filter((r) => Number(r.season) === season);
    if (q === "Runs by a player in a season") {
      const r = rows.find((x) => String(x.player) === player);
      resultBox.textContent = r
        ? `${player} (${season})\n- Runs: ${num(r.total_runs)}\n- Balls: ${num(r.balls_faced)}\n- Strike Rate: ${num(r.strike_rate).toFixed(2)}`
        : `No batting record found for ${player} in ${season}.`;
      return;
    }
    if (q === "Top 5 batsmen in a season") {
      resultBox.textContent = [...rows].sort((a, b) => num(b.total_runs) - num(a.total_runs)).slice(0, 5)
        .map((r, i) => `${i + 1}. ${r.player} - ${num(r.total_runs)} runs`)
        .join("\n");
      return;
    }
    if (q === "Highest run scorer in a season") {
      const r = [...rows].sort((a, b) => num(b.total_runs) - num(a.total_runs))[0];
      resultBox.textContent = r ? `Highest run scorer in ${season}: ${r.player} (${num(r.total_runs)} runs).` : "No data.";
      return;
    }
    if (q === "Best strike rate players (min 100 balls)") {
      resultBox.textContent = rows.filter((r) => num(r.balls_faced) >= 100)
        .sort((a, b) => num(b.strike_rate) - num(a.strike_rate))
        .slice(0, 10)
        .map((r, i) => `${i + 1}. ${r.player} - SR ${num(r.strike_rate).toFixed(2)}, Balls ${num(r.balls_faced)}`)
        .join("\n");
      return;
    }
  }

  if (category === "Player Records - Bowling") {
    const rows = state.bowling.filter((r) => Number(r.season) === season);
    if (q === "Bowling stats of a player in a season") {
      const r = rows.find((x) => String(x.player) === player);
      resultBox.textContent = r
        ? `${player} (${season})\n- Wickets: ${num(r.wickets)}\n- Balls: ${num(r.balls_bowled)}\n- Economy: ${num(r.economy).toFixed(2)}`
        : `No bowling record found for ${player} in ${season}.`;
      return;
    }
    if (q === "Most wickets in a season") {
      resultBox.textContent = [...rows].sort((a, b) => num(b.wickets) - num(a.wickets)).slice(0, 5)
        .map((r, i) => `${i + 1}. ${r.player} - ${num(r.wickets)} wickets`)
        .join("\n");
      return;
    }
    if (q === "Best bowler in a season (wickets)") {
      const r = [...rows].sort((a, b) => num(b.wickets) - num(a.wickets) || num(a.economy) - num(b.economy))[0];
      resultBox.textContent = r ? `Best bowler in ${season}: ${r.player} (${num(r.wickets)} wickets, economy ${num(r.economy).toFixed(2)}).` : "No data.";
      return;
    }
    if (q === "Best economy bowlers") {
      resultBox.textContent = rows.filter((r) => num(r.balls_bowled) >= 120)
        .sort((a, b) => num(a.economy) - num(b.economy))
        .slice(0, 10)
        .map((r, i) => `${i + 1}. ${r.player} - Economy ${num(r.economy).toFixed(2)}, Balls ${num(r.balls_bowled)}`)
        .join("\n");
      return;
    }
  }

  if (category === "Team Records") {
    const big = state.values.filter((r) => r.is_big_buy === true || r.is_big_buy === "True");
    const merged = big.map((r) => {
      const a = state.awards.find((x) => Number(x.season) === Number(r.season)) || {};
      return { ...r, ...a };
    });
    const scoped = merged.filter((r) => String(r.highest_buy_team || "").toLowerCase() === String(team).toLowerCase());
    if (!scoped.length) {
      resultBox.textContent = `No processed team-mapped records found for ${team}.`;
      return;
    }
    if (q === "Top batsmen in selected team") {
      resultBox.textContent = [...scoped].sort((a, b) => num(b.buy_runs) - num(a.buy_runs)).slice(0, 5)
        .map((r, i) => `${i + 1}. ${r.player} (${r.season}) - ${num(r.buy_runs)} runs`)
        .join("\n");
      return;
    }
    if (q === "Top bowlers in selected team") {
      resultBox.textContent = [...scoped].sort((a, b) => num(b.buy_wickets) - num(a.buy_wickets)).slice(0, 5)
        .map((r, i) => `${i + 1}. ${r.player} (${r.season}) - ${num(r.buy_wickets)} wickets`)
        .join("\n");
      return;
    }
    if (q === "Best player in selected team for a season") {
      const one = scoped.filter((r) => Number(r.season) === season).sort((a, b) => num(b.raw_score) - num(a.raw_score))[0];
      resultBox.textContent = one
        ? `Best player in ${team} for ${season} (available mapping): ${one.player} with raw score ${num(one.raw_score).toFixed(2)}.`
        : `No ${team} highest-buy record for ${season}.`;
      return;
    }
  }

  resultBox.textContent = "No matching query handler found.";
}

function applyScrollEffects() {
  const parallaxEls = document.querySelectorAll(".parallax");
  const y = window.scrollY || 0;
  parallaxEls.forEach((el) => {
    el.style.transform = `translateY(${y * 0.15}px) scale(1.06)`;
  });
}

function setupRevealAnimations() {
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) entry.target.classList.add("in-view");
      });
    },
    { threshold: 0.15 }
  );
  document.querySelectorAll(".reveal").forEach((el) => observer.observe(el));
}

function renderTopNumbers() {
  const seasons = [...new Set(state.awards.map((r) => Number(r.season)))];
  const players = [...new Set(state.values.map((r) => r.player))];
  const playerSeasons = state.values.length;
  const hit = state.awards.filter((r) => r.won_any === true || r.won_any === "True").length;
  const hitRate = seasons.length ? (hit / seasons.length) * 100 : 0;

  statSeasons.textContent = `${seasons.length}`;
  statPlayers.textContent = `${players.length}`;
  statDeliveries.textContent = `${playerSeasons}`;
  statHitRate.textContent = `${hitRate.toFixed(1)}`;
}

async function init() {
  try {
    const [batting, bowling, values, awards] = await Promise.all([
      loadCSV("../data/processed/batting_agg.csv"),
      loadCSV("../data/processed/bowling_agg.csv"),
      loadCSV("../data/processed/player_value_scores.csv"),
      loadCSV("../data/processed/ipl_awards_prices.csv"),
    ]);
    state.batting = batting;
    state.bowling = bowling;
    state.values = values;
    state.awards = awards;
    state.seasons = [...new Set(values.map((r) => Number(r.season)))].sort((a, b) => a - b);
    state.teams = [...new Set(awards.map((r) => r.highest_buy_team).filter(Boolean))].sort();

    setOptions(seasonSelect, state.seasons);
    setOptions(teamSelect, state.teams);
    updateUI();
    renderTopNumbers();
    setupRevealAnimations();
    applyScrollEffects();
    resultBox.textContent = "Data loaded. Choose options and click Run Query.";
  } catch (err) {
    resultBox.textContent = `Failed to initialize demo: ${err.message}`;
  }
}

categorySelect.addEventListener("change", () => {
  updateUI();
});
seasonSelect.addEventListener("change", () => {
  updatePlayers();
});
document.getElementById("runBtn").addEventListener("click", runQuery);
window.addEventListener("scroll", applyScrollEffects, { passive: true });

init();
